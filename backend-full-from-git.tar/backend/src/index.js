const path = require('path');
const fs = require('fs');
// Load .env from backend folder (works when cwd is backend or project root)
const backendEnv = path.join(__dirname, '../.env');
require('dotenv').config({ path: backendEnv });
if (!process.env.ADMIN_SECRET && process.cwd() !== path.dirname(backendEnv)) {
  const cwdBackendEnv = path.join(process.cwd(), 'backend', '.env');
  if (fs.existsSync(cwdBackendEnv)) require('dotenv').config({ path: cwdBackendEnv });
}
const isProd = process.env.NODE_ENV === 'production';

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  process.exitCode = 1;
});
// Only disable TLS verification in dev when explicitly enabled (e.g. self-signed APIs).
// Avoids "NODE_TLS_REJECT_UNAUTHORIZED makes TLS insecure" warning when unset.
if (!isProd && process.env.ALLOW_INSECURE_TLS === '1') {
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
}
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');

const adminRoutes = require('./routes/admin');
const authRoutes = require('./routes/auth');
const couponsRoutes = require('./routes/coupons');
const offersRoutes = require('./routes/offers');
const bookingsRoutes = require('./routes/bookings');
const badgesRoutes = require('./routes/badges');
const businessRoutes = require('./routes/business');
const categoriesRoutes = require('./routes/categories');
const eventsRoutes = require('./routes/events');
const feedRoutes = require('./routes/feed');
const interestsRoutes = require('./routes/interests');
const placesRoutes = require('./routes/places');
const profileRoutes = require('./routes/profile');
const toursRoutes = require('./routes/tours');
const tripsRoutes = require('./routes/trips');
const tripSharesRoutes = require('./routes/trip_shares');
const audioGuidesRoutes = require('./routes/audio_guides');
const uploadRoutes = require('./routes/upload');
const aiRoutes = require('./routes/ai');
const reviewsRoutes = require('./routes/reviews');
const { query } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

// --- Production security: fail fast if critical secrets missing or weak ---
if (isProd) {
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
    console.error('FATAL: In production JWT_SECRET must be set and at least 32 characters.');
    process.exit(1);
  }
  const corsOrigin = (process.env.CORS_ORIGIN || '').trim();
  if (!corsOrigin) {
    console.warn('CORS_ORIGIN not set; defaulting to * for this run. Set CORS_ORIGIN in Render Dashboard for production.');
    process.env.CORS_ORIGIN = '*';
  }
  if (process.env.ALLOW_INSECURE_TLS === '1') {
    console.warn('Warning: ALLOW_INSECURE_TLS is ignored in production.');
  }
}
app.disable('x-powered-by');
app.set('trust proxy', 1);

const smtpConfig = require('./config/smtpConfig');
if (!smtpConfig.isConfigured()) {
  console.warn('SMTP not configured: password reset & verification emails will be logged to console only.');
}

// --- Security (extreme) ---
const { blockSuspiciousInput } = require('./middleware/security');
const helmetOptions = {
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
  crossOriginResourcePolicy: { policy: 'same-site' },
  hsts: isProd ? { maxAge: 31536000, includeSubDomains: true, preload: true } : false,
  xContentTypeOptions: true, // sets X-Content-Type-Options: nosniff
  xFrameOptions: { action: 'deny' },
  xXssProtection: true,
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
};
app.use(helmet(helmetOptions));
// Compression first so all JSON and static responses are gzipped (faster over network).
app.use(compression());

const allowedOriginsRaw = (process.env.CORS_ORIGIN || '').trim();
const allowedOrigins = allowedOriginsRaw
  ? allowedOriginsRaw.split(',').map(o => o.trim()).filter(Boolean)
  : [];
const allowAllOrigins = allowedOrigins.length === 0 || (allowedOrigins.length === 1 && allowedOrigins[0] === '*');
app.use(cors({
  origin: allowAllOrigins
    ? true
    : (origin, cb) => {
        if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
        return cb(null, false);
      },
  credentials: true,
  maxAge: 86400,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Admin-Key'],
  optionsSuccessStatus: 204,
}));

app.use(express.json({ limit: '256kb' }));
app.use(blockSuspiciousInput);

// Health routes first (no rate limit) so they always match
const healthDbHandler = (req, res) => {
  query('SELECT 1')
    .then(() => res.json({ status: 'ok', db: 'connected' }))
    .catch((err) => {
      console.error('Health DB check failed:', err.message);
      res.status(503).json({
        status: 'error',
        db: 'failed',
        error: 'Database unavailable',
        ...(isProd ? {} : { detail: err.message }),
      });
    });
};
app.get('/health', (req, res) => res.json({ status: 'ok' }));
app.get('/health/db', healthDbHandler);
app.get('/health/db/', healthDbHandler);
app.get('/api/health', (req, res) => res.json({ status: 'ok' }));
app.get('/api/health/db', healthDbHandler);
app.get('/api/health/db/', healthDbHandler);
app.get('/health/email', (req, res) => {
  if (isProd) return res.json({ status: 'ok' });
  return res.json({ smtpConfigured: !!require('./config/smtpConfig').isConfigured() });
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: isProd ? 60 : 80,
  message: { error: 'Too many requests. Please slow down.' },
  standardHeaders: true,
  legacyHeaders: false,
});
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 15,
  message: { error: 'Too many attempts. Try again later.' },
  standardHeaders: true,
});
const forgotPasswordLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  message: { error: 'Too many password reset requests. Try again later.' },
  standardHeaders: true,
});
app.use('/api', apiLimiter);
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/register', authLimiter);
app.use('/api/auth/forgot-password', forgotPasswordLimiter);
const adminLimiter = rateLimit({ windowMs: 60 * 1000, max: isProd ? 30 : 50, message: { error: 'Too many requests.' }, standardHeaders: true });
app.use('/api/admin', adminLimiter);
const uploadLimiter = rateLimit({ windowMs: 60 * 1000, max: 20, message: { error: 'Too many uploads.' }, standardHeaders: true });
app.use('/api/upload', uploadLimiter);
const aiLimiter = rateLimit({ windowMs: 60 * 1000, max: 30, message: { error: 'Too many AI requests. Try again in a minute.' }, standardHeaders: true });
app.use('/api/ai', aiLimiter);

const uploadsDir = process.env.UPLOADS_PATH
  ? path.resolve(path.join(__dirname, '../..'), process.env.UPLOADS_PATH)
  : path.join(__dirname, '../uploads');
try {
  require('fs').mkdirSync(uploadsDir, { recursive: true });
} catch (_) { /* ignore */ }
// Serve uploads with long cache for fastest repeat loads (images outside app path can use UPLOADS_BASE_URL/CDN)
app.use('/uploads', express.static(uploadsDir, {
  index: false,
  redirect: false,
  maxAge: isProd ? 31536000000 : 300000,
  etag: true,
  setHeaders: (res) => {
    res.set('Cache-Control', isProd ? 'public, max-age=31536000, immutable' : 'public, max-age=300');
  },
}));

// Standalone admin page: upload place images & edit place data (outside the Flutter app)
const publicDir = path.join(__dirname, '../public');
const adminPlacesPath = path.join(publicDir, 'admin-places.html');
app.get('/admin-places.html', (req, res) => {
  res.sendFile(adminPlacesPath, (err) => {
    if (err) {
      if (err.code === 'ENOENT') res.status(404).send('Not found');
      else res.status(500).send('Error');
    }
  });
});
app.get('/admin-places', (req, res) => res.redirect(301, '/admin-places.html'));
app.use(express.static(publicDir, { index: false }));

app.use('/api/auth', authRoutes);
app.use('/api/coupons', couponsRoutes);
app.use('/api/offers', offersRoutes);
app.use('/api/bookings', bookingsRoutes);
app.use('/api/badges', badgesRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/places', placesRoutes);
app.use('/api/categories', categoriesRoutes);
app.use('/api/tours', toursRoutes);
app.use('/api/events', eventsRoutes);
app.use('/api/interests', interestsRoutes);
app.use('/api/user', profileRoutes);
app.use('/api/user', tripsRoutes);
app.use('/api/trip-shares', tripSharesRoutes);
app.use('/api/audio-guides', audioGuidesRoutes);
app.use('/api/feed', feedRoutes);
app.use('/api/business', businessRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/reviews', reviewsRoutes);

app.use((err, req, res, next) => {
  if (err.code === 'LIMIT_FILE_SIZE') return res.status(400).json({ error: 'File too large' });
  if (err.message?.includes('Invalid file type')) return res.status(400).json({ error: err.message });
  if (isProd) {
    console.error(err.message || err);
  } else {
    console.error(err);
  }
  res.status(500).json({ error: isProd ? 'An error occurred' : (err.message || 'An error occurred') });
});

const HOST = process.env.HOST || '0.0.0.0';
app.listen(PORT, HOST, () => {
  console.log(`Tripoli Explorer API running on http://${HOST}:${PORT}`);
  query('SELECT 1')
    .then(() => console.log('DB connected.'))
    .catch((err) => console.error('DB check failed:', err.message, '- Run migrations with same DATABASE_URL as production. See backend/RENDER-500-PLACES.md'));
});
